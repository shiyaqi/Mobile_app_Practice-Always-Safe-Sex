angular.module('starter.controllers', [])

.controller('AppCtrl', function($scope, $ionicModal, $timeout) {

  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //$scope.$on('$ionicView.enter', function(e) {
  //});

  // Form data for the login modal
  $scope.loginData = {};


  // Create the login modal that we will use later
  $ionicModal.fromTemplateUrl('templates/login.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.modal = modal;
  });

  // Triggered in the login modal to close it
  $scope.closeLogin = function() {
    $scope.modal.hide();
  };

  // Open the login modal
  $scope.login = function() {
    $scope.modal.show();
  };

  // Perform the login action when the user submits the login form
  $scope.doLogin = function() {
    console.log('Doing login', $scope.loginData);

    // Simulate a login delay. Remove this and replace with your login
    // code if using a login system
    $timeout(function() {
      $scope.closeLogin();
    }, 1000);
  };
})

.controller('PlaylistsCtrl', function($scope) {
  $scope.playlists = [
    { title: 'Gonorrhea', id: 0 },
    { title: 'Chlamydia', id: 1 },
    { title: 'Trichomoniasis', id: 2 },
    { title: 'Genital Herpes', id: 3 },
    { title: 'Genital Warts and HPV', id: 4 },
    { title: 'Syphilis', id: 5 }
  ];
})

 .controller('PlaylistCtrl', function($scope, $stateParams, Diseases) {
 $scope.disease = Diseases.get($stateParams.diseaseId);
 })

    .controller('KYPCtrl', function($scope, $state) {
        $scope.partnerlist = [
            { text: "Male", value: "Male" },
            { text: "Female", value: "Female" }
        ];
        $scope.data = {
            partner: 'Male'
        };

        $scope.playlists = [
            { title: 'Gonorrhea', id: 0 },
            { title: 'Chlamydia', id: 1 },
            { title: 'Trichomoniasis', id: 2 },
            { title: 'Genital Herpes', id: 3 },
            { title: 'Genital Warts and HPV', id: 4 },
            { title: 'Syphilis', id: 5 }
        ];

        $scope.goSomewhere = function () {
            var path;
            switch($scope.data.partner) {
                case 'Male': path = 'app.male'; break;
                case 'Female': path = 'app.female'; break;
            }
            $state.go(path);
        };
    })

.controller('SplashCtrl', function($scope, $state) {
     console.log('In SplashCtrl');
    $scope.goDisclaimer = function () {
        console.log('In goDisclaimer');
        $state.go('disclaimer');
    };
})

.controller('MyCtrl', function($scope) {

    console.log('In MyCtrl');
    $scope.gotScrolled = function() {
        console.log('Got scrolled');
    };
})

//'use strict';

/*
.controller('BackgroundCtrl', function ($scope) {

    $scope.backgroundImage = {
        background: 'url(img/background.png)'
    };

    console.log($scope.backgroundImage);

});
*/
