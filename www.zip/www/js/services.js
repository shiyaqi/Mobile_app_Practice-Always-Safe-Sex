/**
 * Created by Pat on 7/27/2015.
 */

angular.module('starter.services', [])

    .factory('Diseases', function() {
        // Might use a resource here that returns a JSON array

        // Some fake testing data
        var diseases = [{
            id: 0,
            name: 'Gonorrhea',
            lastText:['Increased vaginal discharge which is greenish yellow or white in color',
                'Increased frequency of urination', 'Pain or burning sensation while urinating', 'Pain or irritation in the vagina or cervix', 'Bleeding between the periods',
                'Spotting after intercourse', 'Swelling in the vulva', 'Lower abdomen or pelvic pain', 'Conjunctivitis (red, itchy eyes)', 'Fever',
                'Throat infection can cause following symptoms (due to oral sex):',
                ' 1. Burning sensation in the throat ',
                '2.  Swollen glands in the throat','Rectal infection can have following symptoms (due to anal sex): ',
                ' 1. Discharge', '2. Anal itching', '3. Soreness',
                '4.  Bleeding', '5. Painful bowel movements'
            ],

            CDClink: 'http://www.cdc.gov/std/gonorrhea/stdfact-gonorrhea-detailed.htm',
            pic:['img/0_1.jpg','img/0_2.jpg','img/0_3.jpg']
        },
            {
            id: 1,
            name: 'Chlamydia',
            lastText: ['No symptoms', 'Abnormal vaginal discharge with odor', 'Increased frequency of urination',
                'Burning sensation while urinating and urinary urgency',
                'Bleeding between the periods',
                'Spotting after intercourse', 'Painful periods', 'Abdominal pain with fever', 'Pain while having intercourse',
                'Itching or burning in or around the vagina',
                'Conjunctivitis (red, itchy eyes)',
                'Rectal infection can cause following symptoms (due to anal or vaginal sex):',
                '1. Rectal pain',
                '2. Discharge','3.  Bleeding'
            ],

            CDClink: 'http://www.cdc.gov/std/chlamydia/stdfact-chlamydia-detailed.htm',
            pic:['img/1_1.png','img/1_2.jpg']
        },
            {
            id: 2,
            name: 'Trichomoniasis',
            lastText: ['No symptoms', 'Painful urination',
                'Abnormal vaginal discharge', 'Greenish-yellow frothy or foamy discharge with strong odor', 'Itching and irritation in or near the vagina',
                'Discomfort during intercourse',
                'Lower abdominal pain'
            ],

            CDClink: 'http://www.cdc.gov/std/trichomonas/stdfact-trichomoniasis.htm',
            pic:['img/2_1.jpg']
        },
            {
            id: 3,
            name: 'Genital Herpes',
            lastText: ['Either no symptoms or very mild ones',
                'Small blisters that break open and cause painful sores  around  the genitals (penis or vagina) or on the buttocks, thighs, or rectal area',
                'Cracked, raw, or red areas around the genitals without pain, itching, or tingling',
                'Itching or tingling around the genitals or the anal region',
                'Pain from urine passing over the sores',
                'Headaches','Backaches',
                'Flu-like symptoms including fever, swollen lymph nodes, and fatigue'],

            CDClink: 'http://www.cdc.gov/std/herpes/stdfact-herpes-detailed.htm',
            pic:['img/3_1.jpg']


        },
            {
            id: 4,
            name: 'Genital Warts and HPV',
            lastText: ['No symptoms', 'Genital warts', 'Warts on cervix, outside or inside vagina or around the anus', 'Warts in the mouth or throat due to oral sex',
                'Warts may cause mild pain, bleeding and itching', 'Cervical cancer usually does not have symptoms until it is quite advanced'],

            CDClink: 'http://www.cdc.gov/std/hpv/stdfact-hpv.htm',
            pic:['img/4_1.jpg']
        },{
            id: 5,
            name: 'Syphilis',
            lastText: ['Primary/Early stage:',
                'One or more small sores ',
                'Painless ulcers - on the genitals or in the mouth between 10-90 days after exposure',
                'Ulcers heal without a scar within six weeks',
                'Secondary stage: Lasts one to three months',
                'A rosy "copper penny" rash typically on the palms of the hands and soles of the feet',
                'Rashes or moist warts in the groin',
                'white patches on the inside of the mouth',
                'swollen lymph glands, fever, and weight loss',
                'Tertiary stage:', 'May progress to severe problems with the heart, brain, and nerves paralysis',
                'Blindness, dementia, deafness,impotence, and even death if not treated'],

            CDClink: 'http://www.cdc.gov/std/syphilis/stdfact-syphilis-detailed.htm',
            pic:['img/5_1.jpg','img/5_2.jpg','img/5_3.jpg','img/5_4.jpg']
        }
        ];

        return {
            all: function() {
                return diseases;
            },
            remove: function(disease) {
                diseases.splice(diseases.indexOf(disease), 1);
            },
            get: function(diseaseId) {
                for (var i = 0; i < diseases.length; i++) {
                    if (diseases[i].id === parseInt(diseaseId)) {
                        return diseases[i];
                    }
                }
                return null;
            }
        };
    });


